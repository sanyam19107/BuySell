package com.iiitd.onCampusUdhaar.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.iiitd.onCampusUdhaar.R;
import com.iiitd.onCampusUdhaar.adapter.AdapterAdvertisement;
import com.iiitd.onCampusUdhaar.helper.ConfigurationFirebase;
import com.iiitd.onCampusUdhaar.helper.RecyclerItemClickListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListAdvertisement extends AppCompatActivity {

    private FirebaseAuth authentication;
    private RecyclerView recyclerAdvertisementPublics;
    private AdapterAdvertisement adapterAdvertisement;
    private List<com.iiitd.onCampusUdhaar.model.Advertisement> listAdvertisements = new ArrayList<>();
    private DatabaseReference advertisementPublicsRef;
    private AlertDialog dialog;
    private String filterCategory = "";
    private View parentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_advertisement);

        authentication = ConfigurationFirebase.getFirebaseAuthentication();
        parentLayout = findViewById(android.R.id.content);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        assert getSupportActionBar() != null;   //null check
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle extras = getIntent().getExtras();
        filterCategory = extras.getString("filterCategory");

        recyclerAdvertisementPublics = findViewById(R.id.recyclerAdvertisementPublics);
        advertisementPublicsRef = ConfigurationFirebase.getFirebase().child("advertisement");
        recyclerAdvertisementPublics.setLayoutManager(new LinearLayoutManager(this));
        recyclerAdvertisementPublics.setHasFixedSize(true);
        adapterAdvertisement = new AdapterAdvertisement(listAdvertisements, this);
        recyclerAdvertisementPublics.setAdapter(adapterAdvertisement);

        recoveryPublicAdvertisement();

        recyclerAdvertisementPublics.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        this,
                        recyclerAdvertisementPublics,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {

                                ConnectivityManager conMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

                                if ( conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                                        || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                                    com.iiitd.onCampusUdhaar.model.Advertisement advertisementSelect = listAdvertisements.get(position);
                                    Intent i = new Intent(ListAdvertisement.this, ProductDetailActivity.class);
                                    i.putExtra("advertisementSelected", advertisementSelect);
                                    startActivity(i);
                                }
                                else
                                    Snackbar.make(parentLayout, R.string.switch_on, Snackbar.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {
                                //Add to Wishlist
                            }

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            }
                        }
                ));

    }

    private void recoveryPublicAdvertisement() {

        dialog = new ProgressDialog(this);
        dialog.setMessage("Fetching ads..");
        dialog.setCancelable(false);
        dialog.show();


        advertisementPublicsRef = ConfigurationFirebase.getFirebase()
                .child("advertisement")
                .child(filterCategory);


        //listAdvertisements.clear();
        advertisementPublicsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listAdvertisements.clear();
                for (DataSnapshot advertisements : dataSnapshot.getChildren()) {
                    com.iiitd.onCampusUdhaar.model.Advertisement advertisement = advertisements.getValue(com.iiitd.onCampusUdhaar.model.Advertisement.class);
                    listAdvertisements.add(advertisement);
                }

                Collections.reverse(listAdvertisements);
                adapterAdvertisement.notifyDataSetChanged();
                dialog.dismiss();
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}
