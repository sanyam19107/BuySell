package com.iiitd.onCampusUdhaar.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.iiitd.onCampusUdhaar.R;
import com.iiitd.onCampusUdhaar.model.Advertisement;
import com.squareup.picasso.Picasso;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

public class ProductDetailActivity extends AppCompatActivity {

    private CarouselView carouselView;
    private TextView title;
    private TextView description;
    private TextView value;
    private Advertisement advertisementSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        assert getSupportActionBar() != null;   //null check
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);   //show back button
        //initialize components
        initializeComponents();

        //Configure toolbar

        //Recovery advertisement for show
        advertisementSelect =  (Advertisement) getIntent().getSerializableExtra("advertisementSelected");
        if(advertisementSelect != null){
            title.setText(advertisementSelect.getTitle());
            description.setText(advertisementSelect.getDescription());
         //   state.setText(advertisementSelect.getState());
            value.setText(advertisementSelect.getValue());

            ImageListener imageListener = new ImageListener() {
                @Override
                public void setImageForPosition(int position, ImageView imageView) {
                    String urlString = advertisementSelect.getPhoto().get(position);
                    Picasso.get().load(urlString).into(imageView); //load image
                }
            };

            carouselView.setPageCount(advertisementSelect.getPhoto().size());
            carouselView.setImageListener(imageListener);
        }

    }

    private void initializeComponents(){
        carouselView = findViewById(R.id.carouselView);
        title = findViewById(R.id.textTitleDetail);
        description = findViewById(R.id.textDescriptionDetail);
        value = findViewById(R.id.textValueDetail);
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

}
