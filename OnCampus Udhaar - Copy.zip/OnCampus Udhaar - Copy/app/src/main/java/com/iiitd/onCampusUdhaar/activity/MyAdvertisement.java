package com.iiitd.onCampusUdhaar.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.iiitd.onCampusUdhaar.R;
import com.iiitd.onCampusUdhaar.adapter.AdapterAdvertisement;
import com.iiitd.onCampusUdhaar.helper.ConfigurationFirebase;
import com.iiitd.onCampusUdhaar.helper.RecyclerItemClickListener;
import com.iiitd.onCampusUdhaar.model.Advertisement;


public class MyAdvertisement extends AppCompatActivity {

    //configurate recyclerView
    private RecyclerView recyclerAdvertisement;
    private List<Advertisement> advertisements = new ArrayList<>();
    private AdapterAdvertisement adapterAdvertisement;
    private DatabaseReference advertisementUserRef;
    private AlertDialog dialog;
    private int pos;
    private View parentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_advertisement);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        parentLayout = findViewById(android.R.id.content);

        //Configurations initial
        advertisementUserRef = ConfigurationFirebase.getFirebase()
                .child("my_advertisement")
                .child(ConfigurationFirebase.getIdUser());

        recyclerAdvertisement = findViewById(R.id.recyclerAdvertisement);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PostAdvertisement.class));
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        //Configurate ReyclerView
        recyclerAdvertisement.setLayoutManager(new LinearLayoutManager(this));
        recyclerAdvertisement.setHasFixedSize(true);
        //Configure Adapter
        adapterAdvertisement = new AdapterAdvertisement(advertisements, this);
        recyclerAdvertisement.setAdapter(adapterAdvertisement);

        recoveryAdvertisement();

        //add event of click in recyclerview
        recyclerAdvertisement.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        this, recyclerAdvertisement,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {
                                pos = position;
                                registerForContextMenu(view);
                            }

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            }
                        }
                )
        );
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu_ads, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ConnectivityManager conMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        switch(item.getItemId())
        {
            case R.id.edit: // For Edit option
            {
                if ( conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                        || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                {
                    com.iiitd.onCampusUdhaar.model.Advertisement advertisementSelect = advertisements.get(pos);
                    Intent i = new Intent(MyAdvertisement.this, ProductDetailActivity.class);
                    i.putExtra("advertisementSelected", advertisementSelect);
                    startActivity(i);
                }
                else
                    Snackbar.make(parentLayout, R.string.switch_on, Snackbar.LENGTH_SHORT).show();

            }
            return true;

            case R.id.delete: // For Delete option
            {
                if ( conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                        || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                {
                    Advertisement advertisementSelected = advertisements.get(pos);
                    advertisementSelected.remove();
                    adapterAdvertisement.notifyDataSetChanged();
                }
                else
                    Snackbar.make(parentLayout, R.string.switch_on, Snackbar.LENGTH_SHORT).show();
            }
            return true;

            default:
                return super.onContextItemSelected(item);
        }
    }

    private void recoveryAdvertisement() {

        dialog = new ProgressDialog(this);
        dialog.setMessage("Fetching ads..");
        dialog.setCancelable(false);
        dialog.show();

        advertisementUserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                advertisements.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    advertisements.add(ds.getValue(Advertisement.class));
                }

                Collections.reverse(advertisements);
                adapterAdvertisement.notifyDataSetChanged();
                dialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}