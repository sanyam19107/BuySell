package com.iiitd.onCampusUdhaar.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.iiitd.onCampusUdhaar.R;
import com.iiitd.onCampusUdhaar.helper.ConfigurationFirebase;
import com.iiitd.onCampusUdhaar.helper.Permission;
import com.iiitd.onCampusUdhaar.model.Advertisement;
import com.santalu.widget.MaskEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PostAdvertisement extends AppCompatActivity implements View.OnClickListener{

    private EditText fieldTitle, fieldDescription;
    private ImageView image1, image2, image3;
    private Spinner fieldState, fieldCategory;
    private EditText fieldValue;
    private EditText fieldPhone;
    private Advertisement advertisement;
    private StorageReference storage;
    private AlertDialog dialog;
    private View parentLayout;

    private String[] permission = new String[]{

            Manifest.permission.READ_EXTERNAL_STORAGE
    };

   private List<String> listPhotoRecovery = new ArrayList<>();
   private List<String> listUrlPhotos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_advertisement);
        parentLayout = findViewById(android.R.id.content);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        assert getSupportActionBar() != null;   //null check
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);   //show back button

        //configurate initial
        storage = ConfigurationFirebase.getFirebaseStorage();

        //validate permission
        Permission.validatePermission(permission, this, 1);

        initializeComponents();
        loadingDataSpinner();
    }


    public void saveAdvertisement(){
        ConnectivityManager conMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if ( conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            dialog = new ProgressDialog(this);
            dialog.setMessage("Posting ad..");
            dialog.setCancelable(false);
            dialog.show();

            for(int i=0; i < listPhotoRecovery.size(); i++){
                String urlImage = listPhotoRecovery.get(i);
                int sizeList = listPhotoRecovery.size();
                savePhotoStorage(urlImage, sizeList, i);
            }
        }
        else
            Snackbar.make(parentLayout, R.string.switch_on, Snackbar.LENGTH_SHORT).show();
    }

    private void savePhotoStorage(String urlString, final int totalPhotos, int cont){
        //Create nó in firebase
        StorageReference imageAdvertisement = storage.child("images")
                .child("advertisement")
                .child(advertisement.getIdAdvertisement())
                .child("image"+cont);

        // make upload of file
        UploadTask uploadTask = imageAdvertisement.putFile( Uri.parse(urlString) );

        uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                Uri firebaseUrl = taskSnapshot.getDownloadUrl();
                String urlConvert = firebaseUrl.toString();

                listUrlPhotos.add(urlConvert);

                if(totalPhotos == listUrlPhotos.size()){
                    advertisement.setPhoto(listUrlPhotos);
                    advertisement.save();

                    dialog.dismiss();
                    finish();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                showMessageError("Failed to upload");
                Log.i("INFO", "Failed to upload: " + e.getMessage());
            }
        });
    }

    private Advertisement configurateAdvertisement(){
       // String state = fieldState.getSelectedItem().toString();
        String category = fieldCategory.getSelectedItem().toString();
        String title = fieldTitle.getText().toString();
        String value = fieldValue.getText().toString();
        String phone = fieldPhone.getText().toString();
        String description = fieldDescription.getText().toString();

        Advertisement advertisement = new Advertisement();
       // advertisement.setState(state);
        advertisement.setCategory(category);
        advertisement.setTitle(title);
        advertisement.setValue(value);
        advertisement.setPhone(phone);
        advertisement.setDescription(description);

        return advertisement;
    }

    @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
    public void validate(View view){
        String phoneAux = "";
        advertisement = configurateAdvertisement();
        String value = String.valueOf(fieldValue.getText());
        if(fieldPhone.getText() != null){
            phoneAux = fieldPhone.getText().toString();
        }

        if(listPhotoRecovery.size() != 0){
            if(true){
                if(!advertisement.getCategory().isEmpty()){
                    if(!advertisement.getTitle().isEmpty()){
                        if(!value.isEmpty() && !value.equals("0")){
                            if(!advertisement.getPhone().isEmpty() && phoneAux.length() >= 10){
                                if(!advertisement.getDescription().isEmpty()){

                                    saveAdvertisement();

                                }else{
                                    showMessageError("Fill in the description field!");
                                }
                            }else{
                                showMessageError("Fill in the phone field, enter at least 10 numbers!");
                            }
                        }else{
                            showMessageError("Fill in the value field\n!");
                        }
                    }else{
                        showMessageError("Fill in the title field!");
                    }
                }else{
                    showMessageError("Fill in the category field!");
                }
            }else{
                showMessageError("Fill in the state field!");
            }
        }else{
            showMessageError("Select at least one photo");
        }
    }

    private void showMessageError(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imageRegister1:
                choiceImage(1);
                break;
        }
    }

    public void choiceImage(int requestCode){
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK){
            //recovery image
            Uri imageChoice = data.getData();
            String pathImage = imageChoice.toString();

            //Configure image in ImageView
            if(requestCode == 1){
                image1.setImageURI(imageChoice);
            }
            //else if(requestCode == 2){
              //  image2.setImageURI(imageChoice);
           // }else if(requestCode == 3){
             //   image3.setImageURI(imageChoice);
            //}
            listPhotoRecovery.add(pathImage);
        }

    }

    private void initializeComponents(){
        fieldTitle = findViewById(R.id.editTitle);
        fieldDescription = findViewById(R.id.editDescription);
        fieldValue = findViewById(R.id.editValue);
        fieldPhone = findViewById(R.id.editPhone);
       // fieldState = findViewById(R.id.spinnerState);
        fieldCategory = findViewById(R.id.spinnerCategory);

        image1 = findViewById(R.id.imageRegister1);
       // image2 = findViewById(R.id.imageRegister2);
        //image3 = findViewById(R.id.imageRegister3);
        image1.setOnClickListener(this);
       // image2.setOnClickListener(this);
       // image3.setOnClickListener(this);
//
//        //configurate local fot pt - portuguese BR - Brazil
//        Locale locale = new Locale("pt", "BR");
//        fieldValue.setLocale(locale);
    }

    private void loadingDataSpinner(){
       /* String[] state = new String[]{
                "SP", "RS"
        };*/
       //configurate spinner de state
       /*
        String[] estate = getResources().getStringArray(R.array.estate);
        ArrayAdapter<String> adapterState = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item,
                estate
        );
        adapterState.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fieldState.setAdapter(adapterState);
*/
        //configurate spinner de category
        String[] category = getResources().getStringArray(R.array.category);
        ArrayAdapter<String> adapterCategory = new ArrayAdapter<String>(
                    this,android.R.layout.simple_spinner_item,
                category
        );
        adapterCategory.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fieldCategory.setAdapter(adapterCategory);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for(int permissionResult : grantResults){

            if (permissionResult == PackageManager.PERMISSION_DENIED){
                AlertValidationPermission();
            }
        }
    }

    private void AlertValidationPermission(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissions Denied");
        builder.setMessage("To use the app you must accept the permissions");
        builder.setCancelable(false);
        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

}
